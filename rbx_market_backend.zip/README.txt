
RBX MARKET BACKEND

Tính năng:
- Đăng ký
- Đăng nhập JWT
- MySQL
- Danh sách acc Roblox
- Auto giao acc khi mua

Cách chạy:

1. Cài Node.js
https://nodejs.org

2. Import file database.sql vào MySQL

3. Cài package:
npm install

4. Chạy server:
npm start

Server:
http://localhost:3000
