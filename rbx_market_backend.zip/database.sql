
CREATE DATABASE rbx_market;

USE rbx_market;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(255),
  password VARCHAR(255)
);

CREATE TABLE accounts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255),
  price INT,
  username VARCHAR(255),
  password VARCHAR(255),
  sold BOOLEAN DEFAULT 0
);

INSERT INTO accounts (title, price, username, password)
VALUES
('Acc Blox Fruit VIP', 499000, 'rbxvip01', 'pass123'),
('Acc Anime Adventures', 699000, 'animevip01', 'pass456');
