
const express = require("express");
const mysql = require("mysql2");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "rbx_market"
});

db.connect((err) => {
  if (err) {
    console.log("Lỗi database:", err);
  } else {
    console.log("MySQL Connected");
  }
});

// Đăng ký
app.post("/register", async (req, res) => {
  const { username, password } = req.body;

  const hashedPassword = await bcrypt.hash(password, 10);

  db.query(
    "INSERT INTO users (username, password) VALUES (?, ?)",
    [username, hashedPassword],
    (err) => {
      if (err) return res.status(500).json(err);

      res.json({ message: "Đăng ký thành công" });
    }
  );
});

// Đăng nhập
app.post("/login", (req, res) => {
  const { username, password } = req.body;

  db.query(
    "SELECT * FROM users WHERE username = ?",
    [username],
    async (err, result) => {
      if (err) return res.status(500).json(err);

      if (result.length === 0) {
        return res.status(404).json({ message: "Không tìm thấy tài khoản" });
      }

      const user = result[0];

      const check = await bcrypt.compare(password, user.password);

      if (!check) {
        return res.status(401).json({ message: "Sai mật khẩu" });
      }

      const token = jwt.sign(
        { id: user.id },
        "RBX_SECRET_KEY",
        { expiresIn: "7d" }
      );

      res.json({
        token,
        user: {
          id: user.id,
          username: user.username
        }
      });
    }
  );
});

// Lấy danh sách acc
app.get("/accounts", (req, res) => {
  db.query(
    "SELECT * FROM accounts WHERE sold = 0",
    (err, result) => {
      if (err) return res.status(500).json(err);

      res.json(result);
    }
  );
});

// Mua acc
app.post("/buy/:id", (req, res) => {
  const id = req.params.id;

  db.query(
    "SELECT * FROM accounts WHERE id = ?",
    [id],
    (err, result) => {
      if (err) return res.status(500).json(err);

      if (result.length === 0) {
        return res.status(404).json({
          message: "Acc không tồn tại"
        });
      }

      const account = result[0];

      if (account.sold === 1) {
        return res.status(400).json({
          message: "Acc đã bán"
        });
      }

      db.query(
        "UPDATE accounts SET sold = 1 WHERE id = ?",
        [id],
        (err2) => {
          if (err2) return res.status(500).json(err2);

          res.json({
            success: true,
            account: {
              username: account.username,
              password: account.password
            }
          });
        }
      );
    }
  );
});

app.listen(3000, () => {
  console.log("Server running on port 3000");
});
